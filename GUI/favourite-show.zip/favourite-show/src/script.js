function bodyload(){
  document.getElementById("btn1").style.fontSize="15px";
  document.getElementById("btn1").style.backgroundColor="gold";
  document.getElementById("btn1").style.borderRadius="20px";
  document.getElementById("btn1").style.color="black";
  document.getElementById("btn1").style.padding="10px";
  document.getElementById("btn1").style.borderStyle="none";

}
function changetheme(){
  document.getElementById("body").style.backgroundColor="lightblue"
  document.getElementById("body").style.fontSize="15px";
  document.getElementById("one").style.color="#DC8423";
  document.getElementById("two").style.color="#B6B149";
  document.getElementById("three").style.color="#B6B149";
  document.getElementById("four").style.color="#D74628";
  document.getElementById("five").style.color="#DC8423";
  document.getElementById("six").style.color="#DC8423";
  document.getElementById("seven").style.color="#DC8423";
  document.getElementById("eight").style.color="#DC8423";
  document.getElementById("nine").style.color="#DC8423";
  document.getElementById("ten").style.color="#B6B149";

}